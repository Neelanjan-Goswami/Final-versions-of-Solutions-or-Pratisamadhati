var c1= document.getElementById("c1");
var b1= document.getElementById("b1");
var sdr= document.getElementById("sdr");

function cc(){
  var color = b1.value;
  c1.style.backgroundColor=color;
}

function sq(){
  var size = sdr.value;
  var ctx = c1.getContext("2d");
  ctx.clearRect(0,0,c1.width,c1.height);
  ctx.fillStyle="black";
  ctx.fillRect(10,10,size,size);
}

function doBlue() {
  var canvas = document.getElementById("c1");
  canvas.style.backgroundColor = "blue";
}