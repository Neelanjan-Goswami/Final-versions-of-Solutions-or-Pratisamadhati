
var d1 = document.getElementById("div1");
var d2 = document.getElementById("div2");
var b1 = document.getElementById("b1");
var b2 = document.getElementById("b2");
var b3 = document.getElementById("b3");



function cc(){
  d1.className="O";
  d2.className="LG";
}

function ccy(){
  d1.style.backgroundColor="Yellow";
    
}

function ccg(){
  d2.style.backgroundColor="Gold";
}

function sh(){
  var context=d1.getContext("2d");
  context.fillStyle = "Lime";
  context.fillRect(10,10,100,50);
  context.fillRect(190,10,100,50);
  context.fillStyle="Blue";
  context.font="20px Calibri";
  context.fillText("HI",45,40);
}
 function clr(){
   var context=d1.getContext("2d");
   var context2=d2.getContext("2d");
   context.clearRect(0,0,d1.width,d1.height);
   context2.clearRect(0,0,d2.width,d2.height);
 }