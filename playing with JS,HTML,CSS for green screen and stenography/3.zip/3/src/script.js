//function test(){
 //  alert("Test");
//}
var d1 = document.getElementById("div1");
var d2 = document.getElementById("div2");
var b1 = document.getElementById("b1");
var b2 = document.getElementById("b2");
var b3 = document.getElementById("b3");
var b4 = document.getElementById("b4");
var b5 = document.getElementById("b5");
//d1.className="O";
//d2.className="LG";

function cc(){
  d1.className="O";
  d2.className="LG";
}

function ct(){
  d1.innerHTML="Namaskar";
  d2.innerHTML="Alvida";
}

function ccj(){
  d1.style.color="lightyellow";
  d2.style.color="lavender";
}

function cv(){
  b1.value="Done";
  b2.value="by";
  b3.value="Neelanjan";
  b4.value="Goswami";
  b5.value="See You Soon";
}

function ccbj(){  b1.style.backgroundColor="lightyellow";
  b2.style.backgroundColor="lightgreen";
                b3.style.backgroundColor="gold";
                b4.style.backgroundColor="lightblue";
                b5.style.backgroundColor="magenta";
}