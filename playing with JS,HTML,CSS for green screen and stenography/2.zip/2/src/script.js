//function test(){
 //  alert("Test");
//}
var d1 = document.getElementById("div2");

function doRed() {
	d1.style.backgroundColor = "red";
	var ctx = d1.getContext("2d");
	ctx.fillStyle = "#333";
	ctx.fillRect(10, 10, 50, 30);
	ctx.font = "16px Helvetica";
	ctx.fillStyle = "#fff";
	ctx.fillText("Hello", 15, 30);
}

function doBlue() {
	d1.style.backgroundColor = "blue";
	var ctx = d1.getContext("2d");
	ctx.fillStyle = "#333";
	ctx.fillRect(10, 10, 50, 30);
	ctx.font = "16px Helvetica";
	ctx.fillStyle = "#fff";
	ctx.fillText("Hello", 15, 30);
}

function bu(){
   var x =confirm("Press Ok to Confirm");
   if(x){
      alert("You pressed OK!")
   }
   else{
      alert("Are you sure you want to cancel?")
   }
}