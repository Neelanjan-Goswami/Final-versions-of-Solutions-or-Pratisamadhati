var img1=null;
var img2=null;
var c1 = document.getElementById("c1");
var c2 = document.getElementById("c2");
var c3 = document.getElementById("c3");
var b1 = document.getElementById("b1");
var b2 = document.getElementById("b2");
var op = document.getElementById("c3");
function up1(){
  img1 = new SimpleImage(b1);
  img1.drawTo(c1);
  if (img1 !== null || !c1.complete()) {
    alert("foreground loaded");
  }
  else{
    alert("error");
  }
} 

function up2(){
  img2 = new SimpleImage(b2);
  img2.drawTo(c2);
  if (img2 !== null || !c2.complete()) {
    alert("background loaded");
  }
  else{
    alert("error");
  }
}

function gsc(){
  if (img1 === null ||! img1.complete()) {
    alert("foreground not loaded");
  }
  if (img2 === null ||! img2.complete()) {
    alert("background not loaded");
  }
 
  op=new SimpleImage(img1.getWidth(),img1.getHeight());
  for(var pixel of img1.values()){
      var x=pixel.getX();
      var y=pixel.getY();
      var px=img1.getPixel(x,y)
    if (pixel.getGreen() > pixel.getRed() + pixel.getBlue()){
      var px=img2.getPixel(x,y)
    }
    op.setPixel(x,y,px)
  }
  op.drawTo(c3);
}

function clr(){
  cxt1 = c1.getContext("2d");
  cxt2 = c2.getContext("2d");
  cxt3 = c3.getContext("2d");
  cxt1.clearRect(0, 0, img1.width, img1.height);
  cxt2.clearRect(0, 0, img2.width, img2.height);
  cxt3.clearRect(0, 0, img2.width, img2.height);
  alert("Clearing Both Canvases");
}