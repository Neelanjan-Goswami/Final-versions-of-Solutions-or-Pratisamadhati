var c1= document.getElementById("c1");
var fl= document.getElementById("file");
var bl= document.getElementById("b1");
var c2= document.getElementById("c2");
var img = null;
function gs(){
  //var img=new SimpleImage(fl);
  for(var pixel of img.values()){
    var px=(pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3;
    pixel.setRed(px);
    pixel.setGreen(px);
    pixel.setBlue(px);
  }
    img.drawTo(c2);
  
}

function pt(){
  img=new SimpleImage(fl);
  img.drawTo(c1);
}