var t= document.getElementById("t");
var b1= document.getElementById("b1");
var sdr= document.getElementById("sdr");
var fl= document.getElementById("file");

function up(){
  var file=t.value;
  alert("Choose "+file+" ?");
  alert("Choose from below button");
}
function upl(){
  var img=new SimpleImage(fl);
  img.drawTo(c1);
}